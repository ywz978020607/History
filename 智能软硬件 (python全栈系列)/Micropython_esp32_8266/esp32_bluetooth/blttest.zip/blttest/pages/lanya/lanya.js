Page({

  /**
   * 页面的初始数据
   */
  data: {
    connectedDeviceId: "", //已连接设备uuid
    services: "", // 连接设备的服务
    characteristics: "",   // 连接设备的状态值
    writeServicweId: "", // 可写服务uuid
    writeCharacteristicsId: "",//可写特征值uuid
    readServicweId: "", // 可读服务uuid
    readCharacteristicsId: "",//可读特征值uuid
    notifyServicweId: "", //通知服务UUid
    ALLUUID: "0000FFE0-0000-1000-8000-00805F9B34FB" //同时具有可读、可写、通知三种属性的UUID

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  // 初始化蓝牙适配器
  lanya1: function () {
    var that = this;
    wx.openBluetoothAdapter({
      success: function (res) {
        console.log('初始化蓝牙适配器返回' + JSON.stringify(res))
        //页面日志显示
        that.setData({
          msg: JSON.stringify(res)
        })
      },
      fail: function (res) {
        console.log('初始化蓝牙适配器失败' + JSON.stringify(res))
      }
    })
  },
  // 本机蓝牙适配器状态
  lanya2: function () {
    var that = this;
    wx.getBluetoothAdapterState({
      success: function (res) {
        //页面日志显示
        that.setData({
          msg: "本机蓝牙适配器状态" + "/" + JSON.stringify(res.errMsg) + "==是否可用：" + res.available


        })

      },
      fail: function (res) {
        //页面日志显示
        that.setData({
          msg: "本机蓝牙适配器状态" + "/" + JSON.stringify(res.errMsg) + "==是否可用：" + res.available


        })

      }
    })
  },
  //搜索设备
  lanya3: function () {
    var that = this;
    wx.startBluetoothDevicesDiscovery({
      //services: ['FEE7'],
      success: function (res) {
        that.setData({
          msg: "搜索设备" + JSON.stringify(res),
        })
        console.log('搜索设备返回' + JSON.stringify(res))

      }
    })
  },
  // 获取所有已发现的设备
  lanya4: function () {
    var that = this;
    wx.getBluetoothDevices({
      success: function (res) {

        that.setData({
          msg: "搜索设备" + JSON.stringify(res.devices),
          devices: res.devices
        })
        console.log('搜到的蓝牙设备数目：' + res.devices.length)
        console.log('获取到周边搜到的设备信息：' + JSON.stringify(res.devices))
      }
    })
  },
  //连接设备
  connectTO: function (e) {
    var that = this;
    wx.createBLEConnection({
      deviceId: e.currentTarget.id,
      success: function (res) {
        console.log('连接设备返回：' + res.errMsg);
        that.setData({
          connectedDeviceId: e.currentTarget.id,
          msg: "已连接" + e.currentTarget.id + '===' + '连接设备返回：' + res.errMsg,
          msg1: "",
        })
      },
      fail: function () {
        console.log("调用失败");
      },
      complete: function () {
        console.log("调用结束");
      }

    })
    console.log(that.data.connectedDeviceId);
  },
  //停止搜索周边设备
  lanya5: function () {
    var that = this;
    wx.stopBluetoothDevicesDiscovery({
      success: function (res) {
        that.setData({
          msg: "停止搜索周边设备" + "/" + JSON.stringify(res.errMsg),
          sousuo: res.discovering ? "在搜索。" : "未搜索。",
          status: res.available ? "可用。" : "不可用。",
        })
      }
    })
  },
  // 获取连接设备的service服务 www.vxzsk.com V型知识库原创
  lanya6: function () {
    var that = this;
    wx.getBLEDeviceServices({
      // 这里的 deviceId 需要在上面的 getBluetoothDevices 或 onBluetoothDeviceFound 接口中获取
      deviceId: that.data.connectedDeviceId,
      success: function (res) {
        console.log('device services:', JSON.stringify(res.services));
        for (var i = 0; i < res.services.length; i++) {
          console.log(i + "--UUID:------" + res.services[i].uuid)
          //var servicesUuid = res.services[i].uuid

        }
        that.setData({
          services: res.services,
          msg: JSON.stringify(res.services),
        })
      }
    })
  },
  //获取连接设备的所有特征值   www.vxzsk.com V型知识库原创
  lanya7: function () {
    var that = this;
    //var myuuid = that.data.services[2].uuid //具有读写通知属性的服务uuid
    var myuuid = that.data.ALLUUID//具有读、写、通知、属性的服务uuid
    console.log('myuuid' + myuuid)
    wx.getBLEDeviceCharacteristics({
      // 这里的 deviceId 需要在上面的 getBluetoothDevices 或 onBluetoothDeviceFound 接口中获取
      deviceId: that.data.connectedDeviceId,
      // 这里的 serviceId 需要在上面的 getBLEDeviceServices 接口中获取
      serviceId: myuuid,
      success: function (res) {
        for (var i = 0; i < res.characteristics.length; i++) {
          console.log('特征值：' + res.characteristics[i].uuid)

          if (res.characteristics[i].properties.notify) {
            console.log("获取开启notify的ServicweId：", myuuid);
            console.log("获取开启notify的CharacteristicsId：", res.characteristics[i].uuid);
            that.setData({
              notifyServicweId: myuuid,
              notifyCharacteristicsId: res.characteristics[i].uuid,

            })
          }
          if (res.characteristics[i].properties.write) {
            console.log("获取开启write的ServicweId：", myuuid);
            console.log("获取开启write的CharacteristicsId：", res.characteristics[i].uuid);
            that.setData({
              writeServicweId: myuuid,
              writeCharacteristicsId: res.characteristics[i].uuid,
            })

          } else if (res.characteristics[i].properties.read) {
            console.log("读read操作readServicweId：", myuuid);
            console.log("读read操作：readCharacteristicsId", res.characteristics[i].uuid);
            that.setData({
              readServicweId: myuuid,
              readCharacteristicsId: res.characteristics[i].uuid,
            })

          }

        }
        console.log('device getBLEDeviceCharacteristics:', res.characteristics);

        that.setData({
          msg: JSON.stringify(res.characteristics),
        })
      },
      fail: function () {
        console.log("fail");
      },
      complete: function () {
        console.log("complete");
      }
    })


  },
  //启用低功耗蓝牙设备特征值变化时的 notify 功能  www.vxzsk.com V型知识库原创
  lanya8: function () {
    var that = this;
    var notifyServicweId = that.data.ALLUUID//具有读、写、通知、属性的服务uuid
    var notifyCharacteristicsId = that.data.notifyCharacteristicsId;
    console.log("启用notify的serviceId", notifyServicweId);
    console.log("启用notify的notifyCharacteristicsId", notifyCharacteristicsId);

    wx.notifyBLECharacteristicValueChange({
      state: true, // 启用 notify 功能
      // 这里的 deviceId 需要在上面的 getBluetoothDevices 或 onBluetoothDeviceFound 接口中获取
      deviceId: that.data.connectedDeviceId,
      // 这里的 serviceId 需要在上面的 getBLEDeviceServices 接口中获取
      serviceId: notifyServicweId,

      // 这里的 characteristicId 需要在上面的 getBLEDeviceCharacteristics 接口中获取
      characteristicId: that.data.notifyCharacteristicsId,

      success: function (res) {
        console.log('notifyBLECharacteristicValueChange success', res.errMsg)
        var msg = '启动通知notify返回:' + res.errMsg
        that.setData({
          msg: msg
        })
      },
      fail: function () {
        console.log('shibai0');
        console.log(that.data.notifyServicweId);
        console.log(that.data.notifyCharacteristicsId);
      },
    })



  },
  //向蓝牙设备发送16进制数据 www.vxzsk.com V型知识库原创
  lanya10: function () {
    var that = this
    console.log('开始发送指令------------')
    var hex = '010203040506'//设备烧制的指令集,读者朋友可更改成您自己设备烧制的指令集
    // 向蓝牙设备发送16进制数据
    var typedArray = new Uint8Array(hex.match(/[\da-f]{2}/gi).map(function (h) {
      return parseInt(h, 16)
    }))
    console.log(typedArray)
    var buffer1 = typedArray.buffer
    wx.writeBLECharacteristicValue({
      // 这里的 deviceId 需要在上面的 getBluetoothDevices 或 onBluetoothDeviceFound 接口中获取
      deviceId: that.data.connectedDeviceId,
      // 这里的 serviceId 需要在上面的 getBLEDeviceServices 接口中获取
      serviceId: that.data.ALLUUID,
      // 这里的 characteristicId 需要在上面的 getBLEDeviceCharacteristics 接口中获取
      characteristicId: that.data.writeCharacteristicsId,
      // 这里的value是ArrayBuffer类型
      value: buffer1,
      success: function (res) {
        console.log('向蓝牙设备写入返回：writeBLECharacteristicValue success', res.errMsg)
      }
    })



  },
  //接收消息 www.vxzsk.com V型知识库原创
  lanya9: function () {
    var that = this;
    console.log("调用接收消息函数----");


    wx.onBLECharacteristicValueChange(function (res) {
      console.log("接收函数返回值：" + res)
      console.log("接收函数返回值characteristicId：" + res.characteristicId)
      console.log("接收函数返回的serviceId:" + res.serviceId)
      console.log("deviceId" + res.deviceId)
      console.log("长度:" + res.value.byteLength)
      console.log("jieshoudao:" + ab2hex(res.value))
      that.setData({
        jieshou: res.value,
        msg: res.value
      })

    })
  },
  lanya0: function () {
    var that = this;
    wx.closeBLEConnection({
      deviceId: that.data.connectedDeviceId,
      success: function (res) {
        that.setData({
          connectedDeviceId: "",
        })
        console.log('断开蓝牙设备连接返回：' + res.errMsg)
      }
    })
  },
})


// ArrayBuffer转16进度字符串示例
function ab2hex(buffer) {
  var hexArr = Array.prototype.map.call(
    new Uint8Array(buffer),
    function (bit) {
      return ('00' + bit.toString(16)).slice(-2)
    }
  )
  return hexArr.join(',');
}