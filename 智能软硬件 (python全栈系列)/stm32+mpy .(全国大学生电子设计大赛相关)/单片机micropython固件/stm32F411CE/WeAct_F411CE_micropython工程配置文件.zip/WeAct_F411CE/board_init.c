#include "py/mphal.h"

void WeAct_Core_board_early_init(void) {
    mp_hal_pin_output(pin_A4);
    mp_hal_pin_write(pin_A4, 1);
}
