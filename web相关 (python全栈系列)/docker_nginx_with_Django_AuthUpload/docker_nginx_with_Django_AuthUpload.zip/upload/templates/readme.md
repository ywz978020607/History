# username登录用session记录

localStorage.getItem('loggedname')
 null
localStorage.removeItem('loggedname')
 undefined
localStorage.setItem('loggedname','a')
  undefined
localStorage.getItem('loggedname')
 "a"